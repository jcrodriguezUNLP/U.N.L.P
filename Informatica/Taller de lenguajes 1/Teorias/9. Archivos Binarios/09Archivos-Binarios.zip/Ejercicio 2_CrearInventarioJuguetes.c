#include <stdio.h>
#include <string.h>

typedef struct {
    char nombre[50];
    int codigo;
    float precio;
    int cantidad_vendida;
    int stock_actual;
} Juguete;

int main() {
    FILE *archivo;
    Juguete juguete;

    archivo = fopen("inventario.dat", "ab+"); // Crear para agregar al final

    printf("Ingrese juguetes (codigo 0 termina):\n");

    printf("Codigo: ");
    scanf("%d", &juguete.codigo); // Leer primer codigo

    while (juguete.codigo != 0) {

        printf("Nombre: "); scanf("%s", juguete.nombre);
        printf("Precio: "); scanf("%f", &juguete.precio);
        printf("Ventas: "); scanf("%d", &juguete.cantidad_vendida);
        printf("Stock.: "); scanf("%d", &juguete.stock_actual);

        fwrite(&juguete, sizeof(Juguete), 1, archivo);

        printf("Codigo: ");
        scanf("%d", &juguete.codigo);
    }

    // Verificar contenido sin cerrar el archivo
    fseek(archivo, 0, SEEK_SET);
    printf("\nCONTENIDO:\nCOD NOMBRE               PRECIO    VEND    STOCK\n");

    while (fread(&juguete, sizeof(Juguete), 1, archivo) == 1) {
            printf("%-3d %-20s $%-9.2f %-6d %-4d\n",
                   juguete.codigo, juguete.nombre, juguete.precio,
                   juguete.cantidad_vendida, juguete.stock_actual);
    }

    fclose(archivo);
    return 0;
}
