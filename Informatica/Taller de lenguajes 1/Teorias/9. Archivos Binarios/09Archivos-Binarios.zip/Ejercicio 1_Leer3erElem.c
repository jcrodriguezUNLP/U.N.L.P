//Accediendo al 3er. elemento
#include <stdio.h>
int main()
{  FILE * ArchTexto, *ArchBinario;
   int aux, terceroTexto, terceroBinario;

   ArchTexto = fopen("Nros_Texto", "rb");
   fscanf(ArchTexto, "%d", &aux); // primero
   fscanf(ArchTexto, "%d", &aux); // segundo
   fscanf(ArchTexto, "%d", &terceroTexto); // tercero
   printf("3ro. leido secuencialmente = %d\n", terceroTexto);
   fclose(ArchTexto);

   ArchBinario = fopen("Nros_Binario", "rb+");
   if (ArchBinario==NULL)
      printf("Error al abrir el arch. binario!\n");
   else {
      fseek(ArchBinario, 2*sizeof(int), SEEK_SET);
      fread(&terceroBinario, sizeof(int),1,ArchBinario);
      printf("3ro. leido con SEEK del arch. binario = %d\n", terceroBinario);
      fclose(ArchBinario);
   }
   return 0;
}
