#include <stdio.h>
int main()
{  FILE * ArchTexto, *ArchBinario;
   int V[] = {112345670, 21234567, 312345679,
              41234567, 51234567, 61234567};

   ArchTexto = fopen("Nros_Texto", "w");
   if (ArchTexto==NULL)
      printf("Error al abrir el arch. de texto!\n");
   else {
      fprintf(ArchTexto, "%d\n%d\n%d\n%d\n%d\n%d", V[0],
              V[1],V[2],V[3],V[4],V[5]);
      fclose(ArchTexto);
   }

   ArchBinario = fopen("Nros_Binario", "wb");
   if (ArchBinario==NULL)
      printf("Error al abrir el arch. binario!\n");
   else {
      fwrite(V, sizeof(int),6,ArchBinario);
      fclose(ArchBinario);
   }
   return 0;
}
