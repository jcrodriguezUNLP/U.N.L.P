#include <stdio.h>

typedef struct {
    char nombre[50];
    int codigo;
    float precio;
    int cantidad_vendida;
    int stock_actual;
} Juguete;

int main() {
    FILE *archivo;
    Juguete juguete;
    int registros_actualizados = 0;

    // Abrir archivo en modo lectura/escritura binaria
    archivo = fopen("inventario.dat", "r+b");
    if (archivo == NULL) {
        printf("Error: No se pudo abrir el archivo inventario.dat\n");
        return 1;
    }

    printf("Aplicando aumento del 5%% a juguetes con codigos 2 y 3...\n\n");

    // Recorrer el archivo y actualizar precios
    while (fread(&juguete, sizeof(Juguete), 1, archivo) == 1) {
        if (juguete.codigo == 2 || juguete.codigo == 3) {
            float precio_anterior = juguete.precio;
            juguete.precio = juguete.precio * 1.05; // Aumento del 5%

            // Retroceder para sobrescribir el registro
            fseek(archivo, -sizeof(Juguete), SEEK_CUR);
            fwrite(&juguete, sizeof(Juguete), 1, archivo);
            fflush(archivo); // asegura que se escriba antes de la pr�xima lectura

            printf("Codigo %d - %s: $%.2f -> $%.2f\n",
                   juguete.codigo, juguete.nombre, precio_anterior, juguete.precio);
            registros_actualizados++;
        }
    }

    fclose(archivo);

    if (registros_actualizados > 0) {
        printf("\nActualizacion completada. %d juguetes modificados.\n", registros_actualizados);
    } else {
        printf("\nNo se encontraron juguetes con codigos 2 o 3.\n");
    }

    // Mostrar inventario actualizado
    archivo = fopen("inventario.dat", "rb");
    printf("\nINVENTARIO ACTUALIZADO:\n");
    printf("COD NOMBRE               PRECIO    VEND    STOCK\n");

    while (fread(&juguete, sizeof(Juguete), 1, archivo) == 1) {
            printf("%-3d %-20s $%-9.2f %-6d %-4d\n",
                   juguete.codigo, juguete.nombre, juguete.precio,
                   juguete.cantidad_vendida, juguete.stock_actual);
    }

    fclose(archivo);
    return 0;
}
