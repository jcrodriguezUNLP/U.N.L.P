#include <stdio.h>
#include <stdlib.h>

#define N 50
typedef struct{
    char cadena[N];
    char largo;
}linea_t;

int main()
{
    // Apertura del archivo
    FILE * binarito = fopen("prueba.bin", "rb");
    if(binarito==NULL){ // SIEMPRE LA VERIFICACION
		printf("Error en apertura de prueba.bin\n");
		return -1;
	}

    // Trabajando con el archivo
    int lectura_binario = 3;
    // Lectura binario 1
    if (lectura_binario==1){
        linea_t unalinea;
        fread(&unalinea, sizeof(linea_t), 1, binarito);
        while(!feof(binarito)){
            printf("%d | %s\n", unalinea.largo, unalinea.cadena);
            fread(&unalinea, sizeof(linea_t), 1, binarito);
        }
    }
    // Lectura binario 2
    if (lectura_binario==2){
        int cant_bytes, cant_elementos, i;
        linea_t unalinea;
        fseek(binarito, 0, SEEK_END); // me muevo al final
        cant_bytes = ftell(binarito); // en que posicion estoy
        cant_elementos = cant_bytes/sizeof(linea_t);

        fseek(binarito, 0, SEEK_SET); // me muevo al principio
        for(i=0;i<cant_elementos;i++){
            fread(&unalinea, sizeof(linea_t), 1, binarito);
            printf("%d | %s\n", unalinea.largo, unalinea.cadena);
        }
    }
    // Lectura binario 3
    if (lectura_binario==3){
        int cant_bytes, cant_elementos, i;
        fseek(binarito, 0, SEEK_END); // me muevo al final
        cant_bytes = ftell(binarito); // en que posicion estoy
        cant_elementos = cant_bytes/sizeof(linea_t);
        fseek(binarito, 0, SEEK_SET); // me muevo al principio

        linea_t * vector_lineas = (linea_t*)malloc(cant_elementos*sizeof(linea_t));
        fread(vector_lineas,sizeof(linea_t),cant_elementos,binarito);
        for(i=0;i<cant_elementos;i++){
            printf("%d | %s\n", vector_lineas[i].largo, vector_lineas[i].cadena);
        }
        free(vector_lineas);
    }

    // Cerrar archivo
    fclose(binarito);
    return 0;
}
