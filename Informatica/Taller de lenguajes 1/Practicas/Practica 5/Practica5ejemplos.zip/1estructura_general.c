#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 50
int main()
{
    // Apertura del archivo
	FILE * archivito = fopen("prueba.txt", "r");
	if(archivito==NULL){ // SIEMPRE LA VERIFICACION
		printf("Error en apertura de prueba.txt\n");
		return -1;
	}

	// Trabajar con el archivo
	char * cadena = (char*)calloc(N, sizeof(char));
	fgets(cadena, N, archivito); // Lectura
	while(!feof(archivito)){
        // Procesamiento
        cadena[strlen(cadena)-1] = '\0';
        printf("%s\n", cadena);
        // Fin procesamiento
        fgets(cadena, N, archivito); // Lectura
	}

	free(cadena);
	// Cerrar archivo
	fclose(archivito);
	return 0;
}
