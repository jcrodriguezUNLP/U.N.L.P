#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 50
typedef struct{
    char cadena[N];
    char largo;
}linea_t;

int main()
{
    // Apertura de archivos archivo
	FILE * archivito = fopen("prueba.txt", "r");
	if(archivito==NULL){ // SIEMPRE LA VERIFICACION
		printf("Error en apertura de prueba.txt\n");
		return -1;
	}

	FILE * binarito = fopen("prueba.bin", "wb");
    if(binarito==NULL){ // SIEMPRE LA VERIFICACION
		printf("Error en apertura de prueba.txt\n");
		fclose(archivito); // cerrar archivo de texto!
		return -2;
	}
	// Trabajar con el archivo
	linea_t unalinea;
	char * cadena = (char*)calloc(N, sizeof(char));
	fgets(cadena, 50, archivito); // Lectura
	while(!feof(archivito)){
        // Procesamiento
        cadena[strlen(cadena)-1] = '\0';
        printf("%s\n", cadena);
        strcpy(unalinea.cadena, cadena);
        unalinea.largo = strlen(cadena);
        fwrite(&unalinea,sizeof(linea_t),1,binarito);
        // Fin procesamiento
        fgets(cadena, 50, archivito); // Lectura
	}

	free(cadena);
	// Cerrar archivo
	fclose(archivito);
	fclose(binarito);
	return 0;
}
