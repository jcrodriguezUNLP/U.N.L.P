// package creadorDeClases;

public class Capitalize {
    public static String capitalize( String cadena ) {
        return cadena.substring( 0 , 1 ).toUpperCase() + cadena.substring( 1 ) ;
    }
}